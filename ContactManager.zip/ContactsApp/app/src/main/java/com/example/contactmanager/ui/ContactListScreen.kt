package com.example.contactmanager.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.contactmanager.data.Contact

// Οθόνη λίστας επαφών - Εμφανίζει όλες τις αποθηκευμένες επαφές και επιτρέπει την αναζήτηση
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactListScreen(
    state: ContactState,
    onEvent: (ContactEvent) -> Unit,
    onNavigateToContactEntry: () -> Unit,
    onNavigateToContactDetail: (Contact) -> Unit
) {
    var showDeleteDialog by remember { mutableStateOf(false) }
    var contactToDelete by remember { mutableStateOf<Contact?>(null) }

    Scaffold(
        // Διαμόρφωση της μπάρας κορυφής με τίτλο και κουμπί προσθήκης
        topBar = {
            TopAppBar(
                title = { Text("Επαφές") },
                actions = {
                    // Κουμπί προσθήκης νέας επαφής
                    IconButton(onClick = onNavigateToContactEntry) {
                        Icon(
                            Icons.Default.Add, 
                            contentDescription = "Προσθήκη Επαφής",
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                },
                // Χρώματα μπάρας κορυφής σύμφωνα με το θέμα
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Πεδίο αναζήτησης επαφών με εικονίδιο
            OutlinedTextField(
                value = state.query,
                onValueChange = { onEvent(ContactEvent.SetSearchQuery(it)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                placeholder = { Text("Αναζήτηση επαφών") },
                leadingIcon = { 
                    Icon(
                        Icons.Default.Search, 
                        contentDescription = "Εικονίδιο αναζήτησης",
                        tint = MaterialTheme.colorScheme.primary
                    )
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                )
            )

            // Λίστα επαφών με κάρτες
            LazyColumn(
                modifier = Modifier.fillMaxSize()
            ) {
                items(state.contacts) { contact ->
                    // Κάρτα επαφής με δυνατότητα επεξεργασίας και διαγραφής
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .clickable { onNavigateToContactDetail(contact) },
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                    ) {
                        ContactItem(
                            contact = contact,
                            onDeleteClick = {
                                // Εμφάνιση διαλόγου επιβεβαίωσης διαγραφής
                                showDeleteDialog = true
                                contactToDelete = contact
                            },
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            }
        }

        // Διάλογος επιβεβαίωσης διαγραφής επαφής
        if (showDeleteDialog && contactToDelete != null) {
            AlertDialog(
                onDismissRequest = { 
                    showDeleteDialog = false 
                    contactToDelete = null
                },
                title = { Text("Διαγραφή Επαφής") },
                text = { 
                    Text(
                        "Είστε σίγουροι ότι θέλετε να διαγράψετε την επαφή ${contactToDelete?.firstName} ${contactToDelete?.lastName};"
                    ) 
                },
                // Κουμπιά επιβεβαίωσης και ακύρωσης
                confirmButton = {
                    TextButton(
                        onClick = {
                            contactToDelete?.let { onEvent(ContactEvent.DeleteContact(it)) }
                            showDeleteDialog = false
                            contactToDelete = null
                        }
                    ) {
                        Text(
                            "Διαγραφή",
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { 
                            showDeleteDialog = false
                            contactToDelete = null
                        }
                    ) {
                        Text("Ακύρωση")
                    }
                }
            )
        }
    }
}

// Στοιχείο επαφής - Εμφανίζει τα βασικά στοιχεία μιας επαφής
@Composable
private fun ContactItem(
    contact: Contact,
    onDeleteClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Στοιχεία επαφής (όνομα και τηλέφωνο)
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = "${contact.firstName} ${contact.lastName}",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = contact.phoneNumber,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)
            )
        }
        // Κουμπί διαγραφής
        IconButton(onClick = onDeleteClick) {
            Icon(
                Icons.Default.Delete, 
                contentDescription = "Διαγραφή επαφής",
                tint = MaterialTheme.colorScheme.primary
            )
        }
    }
} 