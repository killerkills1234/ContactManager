package com.example.contactmanager.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.contactmanager.data.Contact
import com.example.contactmanager.data.ContactDao
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

// ViewModel για τη διαχείριση των επαφών - Χειρίζεται τη λογική και την κατάσταση της εφαρμογής
class ContactViewModel(
    private val dao: ContactDao  // Data Access Object για πρόσβαση στη βάση δεδομένων
) : ViewModel() {
    // Κατάσταση αναζήτησης - Αποθηκεύει το τρέχον κείμενο αναζήτησης
    private val _searchQuery = MutableStateFlow("")
    
    // Συνδυασμός ροών δεδομένων για την κατάσταση της εφαρμογής
    // Συνδυάζει τη λίστα επαφών με το κείμενο αναζήτησης
    val state = combine(
        dao.getAllContacts(),  // Ροή όλων των επαφών από τη βάση
        _searchQuery          // Ροή του κειμένου αναζήτησης
    ) { contacts, query ->
        ContactState(
            // Φιλτράρισμα επαφών βάσει αναζήτησης
            // Αν δεν υπάρχει κείμενο αναζήτησης, επιστρέφει όλες τις επαφές
            // Αλλιώς φιλτράρει βάσει ονόματος, επωνύμου ή τηλεφώνου
            contacts = if(query.isBlank()) contacts else contacts.filter { 
                it.firstName.contains(query, ignoreCase = true) ||
                it.lastName.contains(query, ignoreCase = true) ||
                it.phoneNumber.contains(query)
            },
            query = query
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),  // Διατηρεί την κατάσταση για 5 δευτερόλεπτα μετά την τελευταία συνδρομή
        ContactState()  // Αρχική κατάσταση
    )

    // Χειρισμός συμβάντων της εφαρμογής
    fun onEvent(event: ContactEvent) {
        when(event) {
            // Διαγραφή επαφής από τη βάση δεδομένων
            is ContactEvent.DeleteContact -> {
                viewModelScope.launch {
                    dao.deleteContact(event.contact)
                }
            }
            // Αποθήκευση νέας επαφής στη βάση δεδομένων
            is ContactEvent.SaveContact -> {
                viewModelScope.launch {
                    dao.insertContact(event.contact)
                }
            }
            // Ενημέρωση υπάρχουσας επαφής στη βάση δεδομένων
            is ContactEvent.UpdateContact -> {
                viewModelScope.launch {
                    dao.updateContact(event.contact)
                }
            }
            // Ενημέρωση του κειμένου αναζήτησης
            is ContactEvent.SetSearchQuery -> {
                _searchQuery.value = event.query
            }
        }
    }
}

// Κλάση που αναπαριστά την κατάσταση του UI
data class ContactState(
    val contacts: List<Contact> = emptyList(),  // Λίστα επαφών προς εμφάνιση
    val query: String = ""                      // Τρέχον κείμενο αναζήτησης
)

// Sealed interface για τα διάφορα συμβάντα που μπορεί να συμβούν στην εφαρμογή
sealed interface ContactEvent {
    data class DeleteContact(val contact: Contact): ContactEvent
    data class SaveContact(val contact: Contact): ContactEvent
    data class UpdateContact(val contact: Contact): ContactEvent
    data class SetSearchQuery(val query: String): ContactEvent
} 