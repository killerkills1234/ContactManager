package com.example.contactmanager.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

// Data Access Object - Διεπαφή για πρόσβαση στη βάση δεδομένων
@Dao
interface ContactDao {
    // Επιστρέφει όλες τις επαφές ταξινομημένες κατά όνομα και επώνυμο
    @Query("SELECT * FROM contacts ORDER BY firstName, lastName")
    fun getAllContacts(): Flow<List<Contact>>
    
    // Εισαγωγή νέας επαφής στη βάση
    @Insert
    suspend fun insertContact(contact: Contact)
    
    // Ενημέρωση υπάρχουσας επαφής
    @Update
    suspend fun updateContact(contact: Contact)
    
    // Διαγραφή επαφής
    @Delete
    suspend fun deleteContact(contact: Contact)
    
    // Αναζήτηση επαφών με βάση το όνομα, επώνυμο ή τηλέφωνο
    @Query("SELECT * FROM contacts WHERE firstName LIKE '%' || :query || '%' OR lastName LIKE '%' || :query || '%' OR phoneNumber LIKE '%' || :query || '%'")
    fun searchContacts(query: String): Flow<List<Contact>>
} 