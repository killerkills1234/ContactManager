package com.example.contactmanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.contactmanager.data.ContactDatabase
import com.example.contactmanager.ui.ContactEntryScreen
import com.example.contactmanager.ui.ContactEvent
import com.example.contactmanager.ui.ContactListScreen
import com.example.contactmanager.ui.ContactViewModel
import com.example.contactmanager.ui.theme.ContactManagerTheme

// Κύρια δραστηριότητα της εφαρμογής
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Δημιουργία της βάσης δεδομένων
        val database = ContactDatabase.getDatabase(applicationContext)
        
        setContent {
            ContactManagerTheme {
                ContactsApp(database)
            }
        }
    }
}

// Κύριο composable της εφαρμογής που διαχειρίζεται την πλοήγηση
@Composable
private fun ContactsApp(database: ContactDatabase) {
    // Δημιουργία του navigation controller
    val navController = rememberNavController()
    // Δημιουργία του ViewModel
    val viewModel: ContactViewModel = viewModel { ContactViewModel(database.dao) }
    val state by viewModel.state.collectAsState()

    // Ρύθμιση της πλοήγησης
    NavHost(
        navController = navController,
        startDestination = Screen.ContactList.route
    ) {
        composable(Screen.ContactList.route) {
            ContactListScreen(
                state = state,
                onEvent = viewModel::onEvent,
                onNavigateToContactEntry = {
                    navController.navigate(Screen.ContactEntry.route)
                },
                onNavigateToContactDetail = { contact ->
                    navController.navigate(Screen.ContactEntry.createRoute(contact.id))
                }
            )
        }
        
        composable(
            route = Screen.ContactEntry.route + "?contactId={contactId}",
            arguments = listOf(
                navArgument("contactId") {
                    type = NavType.IntType
                    defaultValue = -1
                }
            )
        ) { backStackEntry ->
            val contactId = backStackEntry.arguments?.getInt("contactId") ?: -1
            val contact = state.contacts.find { it.id == contactId }
            
            ContactEntryScreen(
                contact = contact,
                onSaveContact = { newContact ->
                    if (contact != null) {
                        viewModel.onEvent(ContactEvent.UpdateContact(newContact))
                    } else {
                        viewModel.onEvent(ContactEvent.SaveContact(newContact))
                    }
                },
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}

sealed class Screen(val route: String) {
    object ContactList : Screen("contacts")
    object ContactEntry : Screen("contact_entry") {
        fun createRoute(contactId: Int) = "$route?contactId=$contactId"
    }
}