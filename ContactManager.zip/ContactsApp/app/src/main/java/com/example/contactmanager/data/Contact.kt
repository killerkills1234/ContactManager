package com.example.contactmanager.data

import androidx.room.Entity
import androidx.room.PrimaryKey

// Κλάση δεδομένων που αναπαριστά μια επαφή στη βάση δεδομένων
@Entity(tableName = "contacts")  // Ορισμός πίνακα στη βάση δεδομένων
data class Contact(
    @PrimaryKey(autoGenerate = true)  // Αυτόματη δημιουργία μοναδικού ID
    val id: Int = 0,
    val firstName: String,    // Όνομα επαφής
    val lastName: String,     // Επώνυμο επαφής
    val phoneNumber: String,  // Αριθμός τηλεφώνου
    val email: String        // Διεύθυνση email
) 