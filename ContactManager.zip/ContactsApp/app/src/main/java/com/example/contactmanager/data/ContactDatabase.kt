package com.example.contactmanager.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

// Κλάση βάσης δεδομένων Room - Διαχειρίζεται τη σύνδεση με τη βάση δεδομένων SQLite
@Database(entities = [Contact::class], version = 1)
abstract class ContactDatabase : RoomDatabase() {
    // Πρόσβαση στο DAO για λειτουργίες βάσης δεδομένων
    abstract val dao: ContactDao
    
    companion object {
        // Singleton instance της βάσης δεδομένων
        @Volatile  // Εξασφαλίζει ότι όλα τα threads βλέπουν την ίδια τιμή
        private var INSTANCE: ContactDatabase? = null
        
        // Δημιουργία ή επιστροφή του instance της βάσης δεδομένων
        fun getDatabase(context: Context): ContactDatabase {
            // Χρήση synchronized για thread safety
            return INSTANCE ?: synchronized(this) {
                // Δημιουργία builder της βάσης δεδομένων
                Room.databaseBuilder(
                    context.applicationContext,
                    ContactDatabase::class.java,
                    "contacts.db"  // Όνομα αρχείου βάσης δεδομένων
                ).build().also { INSTANCE = it }
            }
        }
    }
} 