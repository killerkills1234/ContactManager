package com.example.contactmanager.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors
val PrimaryLight = Color(0xFFFF5722)
val SecondaryLight = Color(0xFF03DAC6)
val BackgroundLight = Color(0xFFF5F5F5)
val SurfaceLight = Color(0xFFFFFFFF)
val OnPrimaryLight = Color(0xFFFFFFFF)
val OnBackgroundLight = Color(0xFF121212)

// Dark Theme Colors
val PrimaryDark = Color(0xFFFF8A65)
val SecondaryDark = Color(0xFF64FFDA)
val BackgroundDark = Color(0xFF121212)
val SurfaceDark = Color(0xFF1E1E1E)
val OnPrimaryDark = Color(0xFF000000)
val OnBackgroundDark = Color(0xFFFFFFFF)