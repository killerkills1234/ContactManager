package com.example.contactmanager.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.contactmanager.data.Contact

// Οθόνη προσθήκης/επεξεργασίας επαφής - Επιτρέπει τη δημιουργία νέας επαφής ή την επεξεργασία υπάρχουσας
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactEntryScreen(
    contact: Contact? = null,  // null για νέα επαφή, υπάρχουσα επαφή για επεξεργασία
    onSaveContact: (Contact) -> Unit,  // Callback για αποθήκευση επαφής
    onNavigateBack: () -> Unit  // Callback για επιστροφή στην προηγούμενη οθόνη
) {
    // Μεταβλητές κατάστασης για τα πεδία της φόρμας
    var firstName by remember { mutableStateOf(contact?.firstName ?: "") }
    var lastName by remember { mutableStateOf(contact?.lastName ?: "") }
    var phoneNumber by remember { mutableStateOf(contact?.phoneNumber ?: "") }
    var email by remember { mutableStateOf(contact?.email ?: "") }

    Scaffold(
        // Διαμόρφωση της μπάρας κορυφής
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        // Διαφορετικός τίτλος ανάλογα με το αν πρόκειται για νέα ή υπάρχουσα επαφή
                        if(contact == null) "Προσθήκη Επαφής" else "Επεξεργασία Επαφής",
                        color = MaterialTheme.colorScheme.onPrimary
                    ) 
                },
                // Κουμπί επιστροφής στην προηγούμενη οθόνη
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            Icons.Default.ArrowBack, 
                            contentDescription = "Επιστροφή",
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        // Κάρτα που περιέχει τη φόρμα
        Card(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Πεδία εισαγωγής στοιχείων επαφής
                OutlinedTextField(
                    value = firstName,
                    onValueChange = { firstName = it },
                    label = { Text("Όνομα") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        focusedLabelColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                    )
                )
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedTextField(
                    value = lastName,
                    onValueChange = { lastName = it },
                    label = { Text("Επίθετο") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        focusedLabelColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                    )
                )
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedTextField(
                    value = phoneNumber,
                    onValueChange = { phoneNumber = it },
                    label = { Text("Τηλέφωνο") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        focusedLabelColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                    )
                )
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        focusedLabelColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                    )
                )
                Spacer(modifier = Modifier.height(32.dp))
                
                // Κουμπί αποθήκευσης
                Button(
                    onClick = {
                        // Έλεγχος εγκυρότητας - απαιτούνται όνομα, επώνυμο και τηλέφωνο
                        if(firstName.isNotBlank() && lastName.isNotBlank() && phoneNumber.isNotBlank()) {
                            onSaveContact(
                                Contact(
                                    id = contact?.id ?: 0,  // Διατήρηση του id για επεξεργασία, 0 για νέα επαφή
                                    firstName = firstName.trim(),
                                    lastName = lastName.trim(),
                                    phoneNumber = phoneNumber.trim(),
                                    email = email.trim()
                                )
                            )
                            onNavigateBack()  // Επιστροφή στην προηγούμενη οθόνη μετά την αποθήκευση
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text("Αποθήκευση")
                }
            }
        }
    }
} 